# tools/update_watcher.py
"""Verified hash-chain ZIP inbox installer for SunOpt.

Usage:
    python tools/update_watcher.py --once
    python tools/update_watcher.py --watch
    python tools/update_watcher.py --status

Update package format 2 is self-contained: each ZIP contains ``manifest.json``
and ``manifest.sha256``.  The manifest contains the SHA-256 of every payload
file plus ``parent_sha256``.  The manifest hash therefore commits to the entire
payload and becomes the release/hash-chain ID.

Legacy format-1 packages with a sibling ``.zip.sha256`` sidecar remain readable
for migration, but new packages no longer require or create a sidecar.

The watcher is intentionally NOT self-updatable through normal packages.
SHA-256 protects integrity and ordering; it does not authenticate the author.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
UPDATES = ROOT / "updates"
INBOX = UPDATES / "inbox"
DONE = UPDATES / "installed"
REJECTED = UPDATES / "rejected"
HISTORY = UPDATES / "history"
RELEASE_FILE = UPDATES / "installed-release.json"

GENESIS_HASH = "0" * 64
MAX_FILES = 500
MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024

ALLOWED_PREFIXES = (
    "src/",
    "public/",
    "rust/",
    "data/localities/",
)
ALLOWED_TOP_LEVEL = {
    "package.json",
    "package-lock.json",
    "next.config.ts",
    "tsconfig.json",
    "eslint.config.mjs",
    "postcss.config.mjs",
    "README.md",
    "README.txt",
    "README_INSTALL.txt",
    "notes.md",
}
DENIED_PARTS = {
    ".git",
    ".next",
    "node_modules",
    "target",
    "updates",
    "tools",
    "cache",
    "__pycache__",
}

HASH_RE = re.compile(r"[0-9a-f]{64}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".updating")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def installed_hash() -> str:
    if not RELEASE_FILE.exists():
        return GENESIS_HASH

    state = json.loads(RELEASE_FILE.read_text(encoding="utf-8"))
    value = state.get("sha256")
    if not isinstance(value, str) or not HASH_RE.fullmatch(value):
        raise ValueError("Corrupt updates/installed-release.json")
    return value


def validate_project_path(name: str) -> str:
    if not isinstance(name, str) or not name:
        raise ValueError("Empty update path")
    if "\\" in name:
        raise ValueError(f"Backslashes forbidden in package path: {name}")

    posix = PurePosixPath(name)
    if posix.is_absolute() or ".." in posix.parts or "." in posix.parts:
        raise ValueError(f"Unsafe update path: {name}")
    if any(part in DENIED_PARTS for part in posix.parts):
        raise ValueError(f"Protected path: {name}")

    allowed = (
        name in ALLOWED_TOP_LEVEL
        or any(name.startswith(prefix) for prefix in ALLOWED_PREFIXES)
    )
    if not allowed:
        raise ValueError(f"Path is outside SunOpt update allow-list: {name}")

    target = (ROOT / Path(*posix.parts)).resolve()
    if not target.is_relative_to(ROOT.resolve()):
        raise ValueError(f"Path escaped project root: {name}")
    return name


def parse_hash_text(data: bytes, label: str) -> str:
    try:
        value = data.decode("ascii").split()[0].lower()
    except (UnicodeDecodeError, IndexError) as exc:
        raise ValueError(f"Invalid {label}") from exc
    if not HASH_RE.fullmatch(value):
        raise ValueError(f"Invalid {label}")
    return value


def read_legacy_sidecar(checksum: Path) -> str:
    return parse_hash_text(checksum.read_bytes(), "ZIP SHA-256 sidecar")


def move_to_done(archive: Path, checksum: Path | None = None) -> None:
    DONE.mkdir(parents=True, exist_ok=True)
    archive_target = DONE / archive.name

    if archive_target.exists() and sha256_file(archive_target) == sha256_file(archive):
        archive.unlink()
    else:
        os.replace(archive, archive_target)

    if checksum is not None and checksum.exists():
        checksum_target = DONE / checksum.name
        if checksum_target.exists() and checksum_target.read_bytes() == checksum.read_bytes():
            checksum.unlink()
        else:
            os.replace(checksum, checksum_target)


def package_has_embedded_hash(archive: Path) -> bool:
    try:
        with zipfile.ZipFile(archive) as z:
            names = set(z.namelist())
            return "manifest.json" in names and "manifest.sha256" in names
    except (OSError, zipfile.BadZipFile):
        # Let install/reject produce the actual error once the file is stable.
        return True


def install(archive: Path) -> None:
    legacy_checksum = archive.with_suffix(archive.suffix + ".sha256")

    with zipfile.ZipFile(archive) as z:
        members = [item for item in z.infolist() if not item.is_dir()]
        names = [item.filename for item in members]
        names_set = set(names)

        if len(names) != len(names_set):
            raise ValueError("Duplicate ZIP members")
        if "manifest.json" not in names_set:
            raise ValueError("Missing manifest.json")

        manifest_bytes = z.read("manifest.json")
        manifest = json.loads(manifest_bytes)
        package_format = manifest.get("format", 1)

        if package_format == 2:
            if "manifest.sha256" not in names_set:
                raise ValueError("Missing embedded manifest.sha256")
            expected_manifest_hash = parse_hash_text(
                z.read("manifest.sha256"),
                "embedded manifest SHA-256",
            )
            actual_manifest_hash = sha256_bytes(manifest_bytes)
            if actual_manifest_hash != expected_manifest_hash:
                raise ValueError("Embedded manifest SHA-256 mismatch")
            release_hash = actual_manifest_hash
            checksum_for_move = None
            metadata_members = {"manifest.json", "manifest.sha256"}
        elif package_format == 1:
            if not legacy_checksum.is_file():
                raise ValueError(
                    "Legacy format-1 package requires sibling .zip.sha256; "
                    "new packages should use embedded format 2"
                )
            expected_zip_hash = read_legacy_sidecar(legacy_checksum)
            actual_zip_hash = sha256_file(archive)
            if actual_zip_hash != expected_zip_hash:
                raise ValueError("ZIP SHA-256 mismatch")
            release_hash = actual_zip_hash
            checksum_for_move = legacy_checksum
            metadata_members = {"manifest.json"}
        else:
            raise ValueError(f"Unsupported update package format: {package_format}")

        current_hash = installed_hash()

        if release_hash == current_hash:
            move_to_done(archive, checksum_for_move)
            print(
                f"Already installed {archive.name}; moved duplicate to updates/installed",
                flush=True,
            )
            return

        parent = manifest.get("parent_sha256")
        if not isinstance(parent, str) or not HASH_RE.fullmatch(parent):
            raise ValueError("Missing/invalid parent_sha256")
        if parent != current_hash:
            raise ValueError(
                "Update rejected: expected parent "
                f"{current_hash}, package parent is {parent} "
                "(old, repeated or out-of-order update)"
            )

        updates = manifest.get("files")
        deletes = manifest.get("delete", [])
        if not isinstance(updates, dict):
            raise ValueError("Manifest files must be an object")
        if not isinstance(deletes, list) or not all(isinstance(x, str) for x in deletes):
            raise ValueError("Manifest delete must be a string array")
        if not updates and not deletes:
            raise ValueError("Manifest contains no changes")
        if set(updates).intersection(deletes):
            raise ValueError("A path cannot be both updated and deleted")
        if len(updates) > MAX_FILES:
            raise ValueError(f"Too many payload files (max {MAX_FILES})")
        if names_set != set(updates) | metadata_members:
            raise ValueError("ZIP entries do not match manifest files")

        payload: dict[str, bytes] = {}
        total_bytes = 0

        for name, hash_value in updates.items():
            validate_project_path(name)
            if not isinstance(hash_value, str) or not HASH_RE.fullmatch(hash_value):
                raise ValueError(f"Invalid file hash in manifest: {name}")

            info = z.getinfo(name)
            if info.file_size > MAX_FILE_BYTES:
                raise ValueError(f"File too large: {name}")
            total_bytes += info.file_size
            if total_bytes > MAX_TOTAL_BYTES:
                raise ValueError("Update payload exceeds total size limit")

            mode = (info.external_attr >> 16) & 0o170000
            if mode not in (0, 0o100000):
                raise ValueError(f"Symlink/special file forbidden: {name}")

            data = z.read(name)
            if sha256_bytes(data) != hash_value:
                raise ValueError(f"File hash mismatch: {name}")
            payload[name] = data

        for name in deletes:
            validate_project_path(name)

    # Everything is validated before the project is touched.
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    history_root = HISTORY / stamp
    touched = list(payload) + list(deletes)
    existed_before: dict[str, bool] = {}

    try:
        for name in touched:
            target = ROOT / Path(*PurePosixPath(name).parts)
            existed_before[name] = target.is_file()
            if target.exists() and not target.is_file():
                raise ValueError(f"Update target is not a regular file: {name}")
            if target.is_file():
                backup = history_root / Path(*PurePosixPath(name).parts)
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)

        for name, data in payload.items():
            target = ROOT / Path(*PurePosixPath(name).parts)
            write_atomic(target, data)

        for name in deletes:
            target = ROOT / Path(*PurePosixPath(name).parts)
            if target.exists():
                target.unlink()

        state = {
            "sha256": release_hash,
            "hash_kind": "manifest-sha256" if package_format == 2 else "zip-sha256",
            "package_format": package_format,
            "package": archive.name,
            "installed_utc": datetime.now(timezone.utc).isoformat(),
            "parent_sha256": current_hash,
        }
        write_atomic(
            RELEASE_FILE,
            (json.dumps(state, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        move_to_done(archive, checksum_for_move)

    except Exception:
        for name in reversed(touched):
            target = ROOT / Path(*PurePosixPath(name).parts)
            backup = history_root / Path(*PurePosixPath(name).parts)
            try:
                if existed_before.get(name) and backup.is_file():
                    write_atomic(target, backup.read_bytes())
                elif not existed_before.get(name) and target.exists() and target.is_file():
                    target.unlink()
            except Exception:
                pass
        raise

    print(
        f"Installed {archive.name}: {len(payload)} updated, "
        f"{len(deletes)} deleted; release {release_hash}; "
        f"originals in {history_root}",
        flush=True,
    )


def reject(archive: Path, exc: Exception) -> None:
    legacy_checksum = archive.with_suffix(archive.suffix + ".sha256")
    print(f"REJECTED {archive.name}: {exc}", flush=True)
    REJECTED.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for file in (archive, legacy_checksum):
        if file.exists():
            destination = REJECTED / file.name
            if destination.exists():
                destination = REJECTED / f"{stamp}-{file.name}"
            os.replace(file, destination)


def scan() -> None:
    INBOX.mkdir(parents=True, exist_ok=True)
    for archive in sorted(INBOX.glob("*.zip")):
        legacy_checksum = archive.with_suffix(archive.suffix + ".sha256")
        if not legacy_checksum.is_file() and not package_has_embedded_hash(archive):
            continue
        try:
            install(archive)
        except Exception as exc:
            reject(archive, exc)


def print_status() -> None:
    print(f"SunOpt root: {ROOT}")
    print(f"Inbox:      {INBOX}")
    print(f"Installed:  {installed_hash()}")
    if RELEASE_FILE.exists():
        print(RELEASE_FILE.read_text(encoding="utf-8").rstrip())
    else:
        print("State:      fresh/genesis")


def main() -> None:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--once", action="store_true")
    mode.add_argument("--watch", action="store_true")
    mode.add_argument("--status", action="store_true")
    args = parser.parse_args()

    if args.status:
        print_status()
        return

    scan()
    if args.watch:
        print(f"Watching {INBOX} (Ctrl+C to stop)", flush=True)
        try:
            while True:
                time.sleep(1)
                scan()
        except KeyboardInterrupt:
            print("Watcher stopped", flush=True)


if __name__ == "__main__":
    main()
