#!/usr/bin/env python3
# Mock end-to-end child start/STOP/restore with an original-version fan ramp.
# Does NOT call NVAPI or change clocks/fans.
from __future__ import annotations
import importlib.util
import os
from pathlib import Path
import sys
import tempfile
sys.path.insert(0, str(Path(__file__).parent))
from sunopt_nvapi_fast_ready import NEW_RAMP
spec = importlib.util.spec_from_file_location('gpu_guard',Path(__file__).with_name('sunopt-gpu-profile-guard.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
    root=Path(td); out=root/'outbox';out.mkdir();runtime=root/'runtime';runtime.mkdir()
    original=root/'nvapi-blackwell-benchmark-guard.py'
    # Only a mock for runtime protocol. The NVAPI markers are deliberately comments.
    script='''# fanControl.readback=\n# curveControl.readback=\n# clockLock.readback=\n# curveControl.restore.\n# fanControl.restore.\nimport argparse,json,time\nfrom pathlib import Path\ndef unused_original_fan_block():\n'''+NEW_RAMP+'''        pass\np=argparse.ArgumentParser()\nfor a in ('gpu','target-voltage-mv','native-vf-frequency-mhz','curve-offset-mhz','cap-band-points','fan-percent','parent-pid','ready-file','stop-file','done-file','log-file'):p.add_argument('--'+a)\na=p.parse_args()\nassert a.fan_percent=='70' and a.curve_offset_mhz=='625'\nPath(a.ready_file).write_text(json.dumps({'status':'READY'}))\nwhile not Path(a.stop_file).exists(): time.sleep(0.03)\nPath(a.log_file).write_text('''+repr('''curveControl.readback=0 (NVAPI_OK)
clockLock.readback=0 (NVAPI_OK)
fanControl.readback=0 (NVAPI_OK)
fanControl.entry=0 index=1 level=70 mode=1
fanControl.entry=1 index=2 level=70 mode=1
clockLock.restore.set=0 (NVAPI_OK)
curveControl.restore.exactMatch=True
fanControl.restore.read=0 (NVAPI_OK)
restoreOk=True
''')+''')\nPath(a.done_file).write_text(json.dumps({'status':'DONE','restoreOk':True}))\n'''
    original.write_text(script,encoding='utf-8')
    client=mod.LegacyNvapiGuard(out,runtime,os.getpid(),'B',script=original)
    client.start()
    result=client.finish()
    assert result['restoreOk'] and result['curveRestoredExactly'] and result['fanControlReadback'] and result['clockLockReadback'],result
    assert original.read_text(encoding='utf-8')==script
    print('MOCK_FAST_READY_PASS: startup, STOP, NVAPI readback validation, restore, original untouched')
    busy=[{'gpuUtilization':95,'clockMHz':3480,'temperatureC':42,'fanPercent':[v,v]} for v in (0,20,40,52,62,68)]
    accepted=mod.make_report(busy,mod.time.monotonic()-1,'requested_stop','B',True,result)
    assert accepted['compliant'] is True and accepted['fanTelemetryVerified'] is False
    wrong=[dict(x,clockMHz=2880) for x in busy]
    rejected=mod.make_report(wrong,mod.time.monotonic()-1,'requested_stop','B',True,result)
    assert rejected['compliant'] is False
    print('MOCK_TELEMETRY_PASS: 3480 accepted, 2880 rejected, fan RPM ramp not treated as command failure')
