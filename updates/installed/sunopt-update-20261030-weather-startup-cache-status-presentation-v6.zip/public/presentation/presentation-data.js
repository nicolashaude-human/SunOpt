// public/presentation/presentation-data.js
// This fallback is replaced automatically at Node server startup.
window.SUNOPT_PRESENTATION_DATA = {
  format: 1,
  generatedAt: null,
  source: {
    postalCode: "8001",
    year: 2023,
    pvSystem: {
      peakPower: 10,
      azimuth: 0,
      inclination: 30,
      systemLoss: 0.14
    },
    cacheSource: "not-generated"
  },
  weatherData: []
};
