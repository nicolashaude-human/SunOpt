# SunOpt – UI-/Dokumentationsscanner (nur lesen)

## Zweck

Inventarisiert alle aktuellen `app`-/`pages`-Oberflächen, Layouts, TSX/JSX-Components,
Styles, Navigation, historische grüne Boxen und mögliche alte Versionen.
Historische Versionen werden aus `updates/history/` (Watcher-Sicherungen),
`git log` / `git show` und üblichen Backup-Verzeichnissen gelesen.

Die Bestandteile werden als ein ZIP nach `updates/outbox/` exportiert.
Der Scanner verändert keine Projektdatei, kein Git-Repository, keine Backups,
keinen Button A/B und keinen produktiven Server.

## Aufruf

```
cd C:\NextJS\SunOpt\sunopt
.\rust\sunopt-node\scripts\RUN_SUNOPT_UI_SCAN.cmd
```

Optional auf einer Projektkopie:
```
node rust/sunopt-node/scripts/scan-sunopt-ui-history.mjs C:\Pfad\Zur\SunOpt-Kopie
```

## Ergebnis

`updates/outbox/sunopt-ui-scan-YYYYMMDD-HHMMSSZ.zip`, `.json` und `.md`.

ZIP enthält `UI_SCAN_REPORT.md`, `inventory.json` und Quelltexte unter:
- `files/current/` – derzeitige Dateien
- `files/watcher-history/` – vom Watcher gesicherte ältere Dateien
- `files/git/` – ältere Git-Revisionen von Pages und UI-Schlüsseldateien
- `files/archive/` – alte lokale Kopien, sofern vorhanden

Identische Datei-Inhalte werden nur einmal archiviert. Die JSON-Inventur verweist
auf den bereits archivierten Inhalt. Scangrenzen: 750 KB pro Datei, 38 MB
Quellmaterial und maximal 2200 eindeutige Quelldateien; übersprungene Dateien
werden im Bericht genannt.

Ausgeschlossen sind insbesondere `.env`, Schlüsseldateien, API-Routen,
`node_modules`, Buildverzeichnisse und Native-Binaries. Vor dem Hochladen
bitte trotzdem den ZIP-Inhalt prüfen: UI-Quellcode kann interne Informationen enthalten.

## Dokumentationsentwurf (noch **nicht** implementiert)

Die künftig harmonisierte Dokumentationsseite zeigt links grüne Prozessboxen und
rechts verständliche Prosa mit Einordnung und Beispielen. Auf kleinen Bildschirmen
stehen Box und Absatz untereinander. Der Prozess beginnt bei den historischen
Next.js-Vektoren und führt über Wrapper, Worker Manager, Rust/N-API, Oxc AST,
Cranelift JIT zu Maschinencode und Ergebnisrückgabe. Der GPU-Zweig wird getrennt
visualisiert. Die Tankvergleich-Page dient als visuelle Referenz.
