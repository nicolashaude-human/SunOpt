import { NextResponse } from "next/server";
import { mkdir, open, rename, rm } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import path from "node:path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Exports the actual scanner's API result. This does not run the scan.
export async function POST(request: Request) {
  let temporary: string | undefined;
  try {
    const bytes = await request.text();
    if (Buffer.byteLength(bytes, "utf8") > 8 * 1024 * 1024) {
      return NextResponse.json({ success: false, error: "Scanbericht ist zu gross (max. 8 MiB)" }, { status: 413 });
    }
    const result: unknown = JSON.parse(bytes);
    if (!result || typeof result !== "object" || Array.isArray(result)) {
      return NextResponse.json({ success: false, error: "Ungueltiger Scanbericht" }, { status: 400 });
    }
    const outbox = path.join(process.cwd(), "updates", "outbox");
    await mkdir(outbox, { recursive: true });
    const now = new Date();
    const stamp = now.toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
    const filename = `llm-diagnostic-scanner-${stamp}-${randomUUID().slice(0, 8)}.json`;
    const destination = path.join(outbox, filename);
    temporary = destination + ".tmp";
    const text = JSON.stringify({ generatedAt: now.toISOString(), source: "SunOpt project-cleanup scanner", result }, null, 2) + "\n";
    const fh = await open(temporary, "wx");
    try {
      await fh.writeFile(text, { encoding: "utf8" });
      await fh.sync();
    } finally {
      await fh.close();
    }
    await rename(temporary, destination);
    temporary = undefined;
    return NextResponse.json({ success: true, filename, directory: "updates/outbox", bytes: Buffer.byteLength(text, "utf8") });
  } catch (error) {
    if (temporary) await rm(temporary, { force: true }).catch(() => undefined);
    return NextResponse.json({ success: false, error: error instanceof Error ? error.message : "Export fehlgeschlagen" }, { status: 500 });
  }
}
