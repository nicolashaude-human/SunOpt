import { DiagnosticScanOutboxButton } from "@/components/diagnostic-scan-outbox-button";

/** Independent entry point: does not replace or alter existing cleanup page. */
export default function DiagnosticScanReportPage() {
  return (
    <main style={{ maxWidth: 860, margin: "3rem auto", padding: "1rem" }}>
      <h1>SunOpt – Diagnosescanner</h1>
      <p>Scanbericht wird nach updates/outbox geschrieben. Der vorhandene grüne Rand kann in der bestehenden Scanneransicht durch Übergabe ihrer Button-Klasse wiederverwendet werden.</p>
      <DiagnosticScanOutboxButton />
    </main>
  );
}
