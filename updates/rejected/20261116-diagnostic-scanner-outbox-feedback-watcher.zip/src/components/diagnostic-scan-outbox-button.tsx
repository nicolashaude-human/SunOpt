"use client";

import { useState } from "react";

type State = "idle" | "running" | "success" | "error";

/**
 * Drop-in control for the existing scanner view. Pass the current button className
 * unchanged; the inline borderColor only activates its existing border on success.
 * The scan is considered completed when the API replies successfully; findings
 * (including passed:false) belong in the report, not in transport status.
 */
export function DiagnosticScanOutboxButton({
  className,
  onScanFinished,
}: {
  className?: string;
  onScanFinished?: (result: unknown) => void;
}) {
  const [state, setState] = useState<State>("idle");
  const [message, setMessage] = useState("");

  async function run() {
    setState("running");
    setMessage("Diagnosescanner laeuft ...");
    try {
      // Existing scan route may be GET or POST; GET is used only on method 405.
      let response = await fetch("/api/debug/project-cleanup/scan", { method: "POST", cache: "no-store" });
      if (response.status === 405) {
        response = await fetch("/api/debug/project-cleanup/scan", { method: "GET", cache: "no-store" });
      }
      if (!response.ok) throw new Error(`Scan-API: HTTP ${response.status}`);
      const result: unknown = await response.json();
      if (result && typeof result === "object" && "error" in result && result.error) {
        throw new Error(String(result.error));
      }
      const exported = await fetch("/api/debug/project-cleanup/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result),
      });
      const confirmation: { success?: boolean; filename?: string; error?: string } = await exported.json();
      if (!exported.ok || !confirmation.success) {
        throw new Error(confirmation.error || `Export: HTTP ${exported.status}`);
      }
      onScanFinished?.(result);
      setMessage(`Scan erfolgreich – updates/outbox/${confirmation.filename}`);
      setState("success");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Scan fehlgeschlagen");
      setState("error");
    }
  }

  return (
    <div>
      <button
        type="button"
        className={className}
        disabled={state === "running"}
        onClick={run}
        // Preserve the EXISTING border: only change its color, not its dimensions or styling.
        style={state === "success" ? { borderColor: "#20c55a", boxShadow: "0 0 0 1px #20c55a" } : undefined}
      >
        {state === "running" ? "Scan laeuft ..." : state === "success" ? "✓ Scan erfolgreich" : state === "error" ? "Scan erneut starten" : "Scan starten"}
      </button>
      <div role="status" aria-live="polite" style={{ marginTop: 6 }}>
        {message}
      </div>
    </div>
  );
}
