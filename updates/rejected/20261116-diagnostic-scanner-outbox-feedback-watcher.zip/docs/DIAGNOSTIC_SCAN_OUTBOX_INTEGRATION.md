# Diagnostic Scanner Outbox – 2026-11-16

This update is intentionally non-destructive: it does not replace the existing
project-cleanup scan route or UI, because their full sources were not provided.

## Included
- `POST /api/debug/project-cleanup/export` persists a scan-result JSON atomically as
  `updates/outbox/llm-diagnostic-scanner-YYYYMMDD-HHMMSSZ-xxxxxxxx.json`.
- `<DiagnosticScanOutboxButton>` calls the existing scan API, exports the result,
  and shows success only after the file is actually written. For an existing
  button, pass through its original CSS className: the green border uses the
  current border instead of replacing its style.
- `/debug/project-cleanup/scan-report` is an independent working entry point.

## To integrate into the EXISTING green-rim button
In the existing scanner page, import:
`import { DiagnosticScanOutboxButton } from "@/components/diagnostic-scan-outbox-button";`
Replace the current scan button with:
`<DiagnosticScanOutboxButton className={YOUR_EXISTING_BUTTON_CLASS} />`
Preserve any existing scan-result UI by passing `onScanFinished={...}`.
The component does not replace the existing layout.

## Verify
1. Launch the Next.js server, open `/debug/project-cleanup/scan-report`.
2. Click `Scan starten`.
3. Check `updates/outbox/llm-diagnostic-scanner-*.json`.
4. A successful write turns the button border green and displays the saved path.
5. If the existing scan API uses a different method/response, adapt the component.

Important: `updates/outbox` is ephemeral and maintained by the user. Do not
store permanent reference datasets here. Watcher must ignore non-ZIP outputs.
