# SunOpt Project Cleanup – Outbox Scan & Existing Green Rim

## Files updated (based exactly on the user-provided source, 2026-11-16)
- `src/app/api/debug/project-cleanup/scan/route.ts`
- `src/app/debug/project-cleanup/page.tsx`

No changes to the existing scan engine, project tree renderer, cleanup commit steps,
Tailwind classes, or download handler. The button already present in the page stays.
No additional scan button, new CSS file, new scan page, or second export API is required.

## Click behavior
1. Click the existing **Scan Project** button.
2. The existing API computes the real scan and its two LLM manifest strings.
3. The API writes three artifacts atomically, using temporary files and renames:
   - `updates/outbox/llm-project-cleanup-<UTC>-<id>.txt` (main LLM manifest)
   - `updates/outbox/llm-project-candidates-<UTC>-<id>.txt` (candidates)
   - `updates/outbox/project-cleanup-scan-<UTC>-<id>.json` (complete API response)
4. Only after all three files are saved does the API return HTTP 200 and `outbox.saved: true`.
5. The existing step LED turns green, the existing green Download frame pulses,
   the Scan button reads `✓ Scan erfolgreich`, and the saved path is shown.
6. If the scan/write fails, the existing error box appears, and success indicators
   stay off. Failed partial reports are cleaned up.
7. The original download button still downloads the same LLM text to the browser.
   Clicking it switches off the pulsing rim as before (via `manifestDownloaded`).

## Filesystem location
`C:\NextJS\SunOpt\sunopt\updates\outbox`

## Verification on Windows
In the project directory:
```
npm run build
Get-ChildItem .\updates\outbox\llm-project-*.txt |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 5 FullName, Length, LastWriteTime
```

Open `/debug/project-cleanup` and press Scan Project (in development mode).
The API is disabled when `NODE_ENV=production` as before.

## Package version / conflict note
The watcher package uses the supplied parent hash from `hash(2).txt`.
If another watcher package has already been installed since that hash, do not
force the installation. Supply the updated `updates/history/hash.txt` to build
an updated package against the current state.

## Compatibility
The user-supplied `apply.tar.zst` was inspected as an archive containing
`src/app/api/debug/project-cleanup/*` handlers; its `scan/route.ts` provided
our input route. This patch replaces only that scan handler and the supplied page.
