// SunOpt acceleration worker configuration smoke test.
// Adjust the import only if the existing native test scripts use another form.

import native from "sunopt-node";

const cases = [
  { cpuWorkers: 6, gpuWorkers: 2 },
  { cpuWorkers: 8, gpuWorkers: 0 },
  { cpuWorkers: 0, gpuWorkers: 1 },
];

for (const options of cases) {
  const result = native.testAccelerationConfig(options);
  console.log(options, "=>", result);
}

try {
  native.testAccelerationConfig({
    cpuWorkers: 0,
    gpuWorkers: 0,
  });

  throw new Error("Expected zero-worker configuration to fail.");
} catch (error) {
  console.log("zero-worker validation: OK");
  console.log(String(error?.message ?? error));
}
