#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, zipfile
from pathlib import Path

ROOT=Path.cwd(); INBOX=ROOT/'updates'/'inbox'; HASH_FILE=ROOT/'updates'/'history'/'hash.txt'
H=ROOT/'rust'/'sunopt-node'/'cuda'/'cuda_context.h'
CU=ROOT/'rust'/'sunopt-node'/'cuda'/'cuda_context.cu'
RS=ROOT/'rust'/'sunopt-node'/'src'/'cuda_context.rs'
H_REL='rust/sunopt-node/cuda/cuda_context.h'; CU_REL='rust/sunopt-node/cuda/cuda_context.cu'; RS_REL='rust/sunopt-node/src/cuda_context.rs'; MJS_REL='rust/sunopt-node/scripts/blackwell-b14i1-lockstep.mjs'
GENESIS='0'*64; HASH_RE=re.compile(r'^[0-9a-f]{64}$')

def parent_hash():
    if not HASH_FILE.is_file(): return GENESIS
    v=HASH_FILE.read_text(encoding='utf-8').strip().lower()
    if not HASH_RE.fullmatch(v): raise SystemExit(f'invalid current hash: {v!r}')
    return v

def insert_before(text, anchor, block, label):
    first=block.splitlines()[0]
    if first in text: raise SystemExit(f'{label}: block already exists')
    p=text.find(anchor)
    if p<0: raise SystemExit(f'{label}: anchor not found: {anchor}')
    return text[:p]+block.rstrip()+'\n\n'+text[p:]

H_BLOCK="""// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_BEGIN
SUNOPT_CUDA_EXPORT int sunopt_cuda_run_b14i1_warp_binary_lockstep_benchmark(
    int device_id,
    const double* host_export_power,
    const double* host_demand_energy,
    size_t data_length,
    const double* host_tank_parameters,
    size_t tank_count,
    const uint32_t* host_current_indices,
    const uint32_t* host_horizon_steps,
    const double* host_dynamic_values,
    const double* host_energy_cut_levels,
    size_t step_count,
    double* host_cut_results,
    double* out_static_h2d_ms,
    double* out_dynamic_h2d_ms,
    double* out_kernel_ms,
    double* out_result_d2h_ms,
    double* out_wall_ms
);
// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_END"""

CU_BLOCK="""// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_BEGIN
extern \"C\" int sunopt_cuda_run_b14i1_warp_binary_lockstep_benchmark(
    int device_id,
    const double* host_export_power,
    const double* host_demand_energy,
    size_t data_length,
    const double* host_tank_parameters,
    size_t tank_count,
    const uint32_t* host_current_indices,
    const uint32_t* host_horizon_steps,
    const double* host_dynamic_values,
    const double* host_energy_cut_levels,
    size_t step_count,
    double* host_cut_results,
    double* out_static_h2d_ms,
    double* out_dynamic_h2d_ms,
    double* out_kernel_ms,
    double* out_result_d2h_ms,
    double* out_wall_ms
) {
    using Clock = std::chrono::steady_clock;
    if (!host_export_power || !host_demand_energy || !host_tank_parameters ||
        !host_current_indices || !host_horizon_steps || !host_dynamic_values ||
        !host_energy_cut_levels || !host_cut_results || !out_static_h2d_ms ||
        !out_dynamic_h2d_ms || !out_kernel_ms || !out_result_d2h_ms || !out_wall_ms ||
        data_length == 0 || tank_count == 0 || step_count == 0)
        return static_cast<int>(cudaErrorInvalidValue);

    cudaError_t err=cudaSetDevice(device_id); if(err!=cudaSuccess) return static_cast<int>(err);
    cudaStream_t stream=nullptr; cudaEvent_t k0=nullptr,k1=nullptr;
    double *d_export=nullptr,*d_demand=nullptr,*d_tanks=nullptr,*d_dynamic=nullptr,*d_energy_cut=nullptr,*d_cut=nullptr;
    uint32_t *d_current=nullptr,*d_horizon=nullptr,*d_status=nullptr,*d_ms=nullptr,*d_mws=nullptr;
    const size_t annual_bytes=data_length*sizeof(double);
    const size_t tank_bytes=tank_count*6*sizeof(double);
    const size_t dyn_bytes=tank_count*2*sizeof(double);
    const size_t cut_bytes=tank_count*sizeof(double);
    const size_t u32_bytes=tank_count*sizeof(uint32_t);
    auto cleanup=[&](){
        if(d_mws)cudaFree(d_mws); if(d_ms)cudaFree(d_ms); if(d_status)cudaFree(d_status); if(d_cut)cudaFree(d_cut);
        if(d_energy_cut)cudaFree(d_energy_cut); if(d_dynamic)cudaFree(d_dynamic); if(d_horizon)cudaFree(d_horizon);
        if(d_current)cudaFree(d_current); if(d_tanks)cudaFree(d_tanks); if(d_demand)cudaFree(d_demand); if(d_export)cudaFree(d_export);
        if(k1)cudaEventDestroy(k1); if(k0)cudaEventDestroy(k0); if(stream)cudaStreamDestroy(stream);
    };
    err=cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    err=cudaEventCreate(&k0); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    err=cudaEventCreate(&k1); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
#define M(P,B) do{err=cudaMalloc(reinterpret_cast<void**>(&(P)),(B));if(err!=cudaSuccess){cleanup();return static_cast<int>(err);}}while(false)
    M(d_export,annual_bytes); M(d_demand,annual_bytes); M(d_tanks,tank_bytes); M(d_current,sizeof(uint32_t)); M(d_horizon,sizeof(uint32_t));
    M(d_dynamic,dyn_bytes); M(d_energy_cut,cut_bytes); M(d_cut,cut_bytes); M(d_status,u32_bytes); M(d_ms,u32_bytes); M(d_mws,u32_bytes);
#undef M
    const auto wall0=Clock::now(); const auto s0=Clock::now();
    err=cudaMemcpyAsync(d_export,host_export_power,annual_bytes,cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    err=cudaMemcpyAsync(d_demand,host_demand_energy,annual_bytes,cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    err=cudaMemcpyAsync(d_tanks,host_tank_parameters,tank_bytes,cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    err=cudaStreamSynchronize(stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
    *out_static_h2d_ms=std::chrono::duration<double,std::milli>(Clock::now()-s0).count();
    double h2d=0.0,d2h=0.0,kernel=0.0;
    for(size_t step=0;step<step_count;++step){
        const auto h0=Clock::now();
        err=cudaMemcpyAsync(d_current,host_current_indices+step,sizeof(uint32_t),cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        err=cudaMemcpyAsync(d_horizon,host_horizon_steps+step,sizeof(uint32_t),cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        err=cudaMemcpyAsync(d_dynamic,host_dynamic_values+step*tank_count*2,dyn_bytes,cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        err=cudaMemcpyAsync(d_energy_cut,host_energy_cut_levels+step*tank_count,cut_bytes,cudaMemcpyHostToDevice,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        h2d+=std::chrono::duration<double,std::milli>(Clock::now()-h0).count();
        err=cudaEventRecord(k0,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        sunopt_b14g_warp_binary_kernel<<<static_cast<unsigned int>(tank_count),SUNOPT_B14G_THREADS,0,stream>>>(
            d_export,d_demand,data_length,d_tanks,tank_count,d_current,d_horizon,d_dynamic,d_energy_cut,1,d_cut,d_status,d_ms,d_mws);
        err=cudaGetLastError(); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        err=cudaEventRecord(k1,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        const auto d0=Clock::now();
        err=cudaMemcpyAsync(host_cut_results+step*tank_count,d_cut,cut_bytes,cudaMemcpyDeviceToHost,stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        err=cudaStreamSynchronize(stream); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} 
        d2h+=std::chrono::duration<double,std::milli>(Clock::now()-d0).count();
        float km=0.0f; err=cudaEventElapsedTime(&km,k0,k1); if(err!=cudaSuccess){cleanup();return static_cast<int>(err);} kernel+=static_cast<double>(km);
    }
    *out_dynamic_h2d_ms=h2d; *out_kernel_ms=kernel; *out_result_d2h_ms=d2h;
    *out_wall_ms=std::chrono::duration<double,std::milli>(Clock::now()-wall0).count();
    cleanup(); return static_cast<int>(cudaSuccess);
}
// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_END"""

RS_FFI="""    // SUNOPT_BLACKWELL_B14I1_LOCKSTEP_FFI_BEGIN
    fn sunopt_cuda_run_b14i1_warp_binary_lockstep_benchmark(
        device_id:c_int, host_export_power:*const f64, host_demand_energy:*const f64, data_length:usize,
        host_tank_parameters:*const f64, tank_count:usize, host_current_indices:*const u32, host_horizon_steps:*const u32,
        host_dynamic_values:*const f64, host_energy_cut_levels:*const f64, step_count:usize, host_cut_results:*mut f64,
        out_static_h2d_ms:*mut f64, out_dynamic_h2d_ms:*mut f64, out_kernel_ms:*mut f64,
        out_result_d2h_ms:*mut f64, out_wall_ms:*mut f64,
    )->c_int;
    // SUNOPT_BLACKWELL_B14I1_LOCKSTEP_FFI_END"""

RS_RESULT="""// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_RESULT_BEGIN
#[napi(object)]
pub struct BlackwellB14i1LockstepResult {
    pub snapshot_path:String, pub device_id:i32, pub annual_step_count:u32, pub tank_count:u32, pub causal_jobs:u32,
    pub static_h2d_ms:f64, pub dynamic_h2d_ms:f64, pub kernel_ms:f64, pub result_d2h_ms:f64, pub wall_ms:f64, pub checksum_hex:String,
}
// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_RESULT_END"""

RS_FN="""// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_FN_BEGIN
#[napi]
pub fn run_blackwell_b14i1_lockstep(snapshot_path:Option<String>,device_id:Option<i32>)->Result<BlackwellB14i1LockstepResult>{
    let path=snapshot_path.map(PathBuf::from).unwrap_or_else(blackwell_default_snapshot_path);
    let snapshot=read_blackwell_snapshot(&path).map_err(|e|Error::from_reason(format!(\"Unable to read Blackwell snapshot {}: {e}\",path.display())))?;
    if snapshot.steps.is_empty()||snapshot.tank_count==0{return Err(Error::from_reason(\"Blackwell snapshot is empty.\"));}
    let tank_parameters=(0..snapshot.tank_count).map(|t|research_tank_from_packed(&snapshot.packed_config,t)).collect::<Vec<_>>();
    let mut packed_tanks=Vec::<f64>::with_capacity(snapshot.tank_count*6);
    for tank in &tank_parameters{packed_tanks.extend_from_slice(&[tank.target_storage_energy,tank.maximum_heat_pump_electrical_power,tank.cop*tank.time_step_hours,tank.heat_loss_retention,tank.heat_loss_intercept,if tank.affine_supported{1.0}else{0.0}]);}
    let step_count=snapshot.steps.len(); let jobs=step_count.checked_mul(snapshot.tank_count).ok_or_else(||Error::from_reason(\"B14I1 job count overflow.\"))?;
    let mut current_indices=Vec::<u32>::with_capacity(step_count); let mut horizons=Vec::<u32>::with_capacity(step_count);
    let mut dynamic_values=Vec::<f64>::with_capacity(jobs*2); let mut energy_cut_levels=Vec::<f64>::with_capacity(jobs);
    for step in &snapshot.steps{
        current_indices.push(step.current_index); horizons.push(step.horizon_steps);
        let export_window=research_window(&snapshot.export_power,step.current_index as usize,step.horizon_steps as usize);
        for tank_index in 0..snapshot.tank_count{
            let base=tank_index*BLACKWELL_DYNAMIC_STRIDE; let tank=tank_parameters[tank_index];
            let current=step.dynamic[base]; let reserve=step.dynamic[base+1]; let requested=step.dynamic[base+2];
            dynamic_values.push(current); dynamic_values.push(reserve);
            energy_cut_levels.push(research_energy_cut_level(&export_window,requested,tank));
        }
    }
    let mut cuts=vec![0.0_f64;jobs]; let mut sh=0.0; let mut dh=0.0; let mut km=0.0; let mut dd=0.0; let mut wm=0.0; let dev=device_id.unwrap_or(0);
    let code=unsafe{sunopt_cuda_run_b14i1_warp_binary_lockstep_benchmark(dev as c_int,snapshot.export_power.as_ptr(),snapshot.demand_energy.as_ptr(),snapshot.data_length,packed_tanks.as_ptr(),snapshot.tank_count,current_indices.as_ptr(),horizons.as_ptr(),dynamic_values.as_ptr(),energy_cut_levels.as_ptr(),step_count,cuts.as_mut_ptr(),&mut sh,&mut dh,&mut km,&mut dd,&mut wm)};
    if code!=0{return Err(cuda_error(\"sunopt_cuda_run_b14i1_warp_binary_lockstep_benchmark\",code));}
    let mut checksum=1469598103934665603_u64; for value in &cuts{blackwell_fnv1a_update(&mut checksum,*value);}
    Ok(BlackwellB14i1LockstepResult{snapshot_path:path.display().to_string(),device_id:dev,annual_step_count:step_count as u32,tank_count:snapshot.tank_count as u32,causal_jobs:jobs as u32,static_h2d_ms:sh,dynamic_h2d_ms:dh,kernel_ms:km,result_d2h_ms:dd,wall_ms:wm,checksum_hex:format!(\"{checksum:016x}\")})
}
// SUNOPT_BLACKWELL_B14I1_LOCKSTEP_FN_END"""

MJS="""import {createRequire} from 'node:module';
import fs from 'node:fs'; import path from 'node:path'; import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url); const here=path.dirname(fileURLToPath(import.meta.url)); const nativeRoot=path.resolve(here,'..'); const projectRoot=path.resolve(nativeRoot,'..','..');
const outbox=path.join(projectRoot,'updates','outbox'); fs.mkdirSync(outbox,{recursive:true});
const addon=require(path.join(nativeRoot,'sunopt_node.win32-x64-msvc.node')); const run=addon.runBlackwellB14i1Lockstep; if(typeof run!=='function')throw new Error('runBlackwellB14i1Lockstep export missing');
const snapshot=process.argv[2]?path.resolve(process.argv[2]):path.join(nativeRoot,'blackwell-b12-sync-blackwell.bin');
console.log('--- B14I1 B14G PRODUCTION-SHAPED LOCKSTEP ---'); console.log(`snapshot=${snapshot}`);
const r=run(snapshot,0); const expected='bf0e8c9e7b5c879e'; const same=r.checksumHex===expected; const report={...r,expectedB14hChecksumHex:expected,checksumMatchesB14h:same};
const reportPath=path.join(outbox,'blackwell-b14i1-lockstep.json'); fs.writeFileSync(reportPath,JSON.stringify(report,null,2)+'\\n');
console.log(`steps=${r.annualStepCount} tanks=${r.tankCount} jobs=${r.causalJobs}`); console.log(`staticH2D=${r.staticH2DMs.toFixed(3)} ms`); console.log(`dynamicH2D=${r.dynamicH2DMs.toFixed(3)} ms`); console.log(`kernel=${r.kernelMs.toFixed(3)} ms`); console.log(`resultD2H=${r.resultD2HMs.toFixed(3)} ms`); console.log(`wall=${r.wallMs.toFixed(3)} ms`); console.log(`checksum=${r.checksumHex}`); console.log(`checksumMatchesB14H=${same}`); console.log(`report=${reportPath}`); console.log(`B14I1_RESULT=${same?'EXACT_PRODUCTION_SHAPED_LOCKSTEP':'CHECKSUM_MISMATCH'}`); console.log(`SUNOPT_B14I1_JSON=${JSON.stringify(report)}`);
"""

h=H.read_text(encoding='utf-8'); cu=CU.read_text(encoding='utf-8'); rs=RS.read_text(encoding='utf-8')
h=insert_before(h,'// SUNOPT_BLACKWELL_MAX_AFFINE_TREE_BEGIN',H_BLOCK,'h')
cu=insert_before(cu,'// SUNOPT_BLACKWELL_MAX_AFFINE_TREE_BEGIN',CU_BLOCK,'cu')
rs=insert_before(rs,'// SUNOPT_BLACKWELL_DIGITAL_HP_BREAKPOINTS_FFI_BEGIN',RS_FFI,'rs ffi')
rs=insert_before(rs,'// SUNOPT_BLACKWELL_B14G_WARP_BINARY_FN_BEGIN',RS_RESULT+'\n\n'+RS_FN,'rs fn')
files={H_REL:h.encode(),CU_REL:cu.encode(),RS_REL:rs.encode(),MJS_REL:MJS.encode()}
parent=parent_hash(); manifest={'format':2,'parent_sha256':parent,'files':{k:hashlib.sha256(v).hexdigest() for k,v in files.items()},'delete':[]}
mb=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode(); release=hashlib.sha256(mb).hexdigest(); INBOX.mkdir(parents=True,exist_ok=True)
zp=INBOX/'20261112-blackwell-b14i1-production-shaped-lockstep.zip'
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr('manifest.json',mb); z.writestr('manifest.sha256',release+'\n')
    for k,v in files.items(): z.writestr(k,v)
print(f'parent={parent}'); print(f'release={release}'); print(f'package={zp}'); print('B14I1_PACKAGE_RESULT=OK')
