# SunOpt native npm hooks

Run once from the SunOpt project root:

    node tools/enable-native-npm-hooks.mjs

The script preserves the existing package.json and adds only:

- native:install
- predev
- prebuild
- prestart

Existing predev/prebuild/prestart commands are retained after the native install step.

A backup is written to:

    package.json.before-native-hooks.bak
