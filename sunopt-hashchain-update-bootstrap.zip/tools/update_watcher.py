# tools/update_watcher.py
"""Verified hash-chain ZIP inbox installer for SunOpt.

Usage:
    python tools/update_watcher.py --once
    python tools/update_watcher.py --watch
    python tools/update_watcher.py --status

Each update ZIP requires a sibling ``.zip.sha256`` sidecar.  Every manifest
contains ``parent_sha256`` equal to the SHA-256 of the previously installed
update ZIP.  A fresh SunOpt checkout starts with the all-zero genesis hash.

The watcher is intentionally NOT self-updatable through normal packages.
SHA-256 protects integrity and ordering; it does not authenticate the author.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
UPDATES = ROOT / "updates"
INBOX = UPDATES / "inbox"
DONE = UPDATES / "installed"
REJECTED = UPDATES / "rejected"
HISTORY = UPDATES / "history"
RELEASE_FILE = UPDATES / "installed-release.json"

GENESIS_HASH = "0" * 64
MAX_FILES = 500
MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024

# Normal update packages may change project/runtime source, but never the
# updater itself, local state, caches, credentials, VCS metadata or build output.
ALLOWED_PREFIXES = (
    "src/",
    "public/",
    "rust/",
    "data/localities/",
)
ALLOWED_TOP_LEVEL = {
    "package.json",
    "package-lock.json",
    "next.config.ts",
    "tsconfig.json",
    "eslint.config.mjs",
    "postcss.config.mjs",
    "README.md",
    "README.txt",
    "README_INSTALL.txt",
    "notes.md",
}
DENIED_PARTS = {
    ".git",
    ".next",
    "node_modules",
    "target",
    "updates",
    "tools",
    "cache",
    "__pycache__",
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".updating")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def installed_hash() -> str:
    if not RELEASE_FILE.exists():
        return GENESIS_HASH

    state = json.loads(RELEASE_FILE.read_text(encoding="utf-8"))
    value = state.get("sha256")
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("Corrupt updates/installed-release.json")
    return value


def validate_project_path(name: str) -> str:
    if not isinstance(name, str) or not name:
        raise ValueError("Empty update path")
    if "\\" in name:
        raise ValueError(f"Backslashes forbidden in package path: {name}")

    posix = PurePosixPath(name)
    if posix.is_absolute() or ".." in posix.parts or "." in posix.parts:
        raise ValueError(f"Unsafe update path: {name}")
    if any(part in DENIED_PARTS for part in posix.parts):
        raise ValueError(f"Protected path: {name}")

    allowed = (
        name in ALLOWED_TOP_LEVEL
        or any(name.startswith(prefix) for prefix in ALLOWED_PREFIXES)
    )
    if not allowed:
        raise ValueError(f"Path is outside SunOpt update allow-list: {name}")

    target = (ROOT / Path(*posix.parts)).resolve()
    if not target.is_relative_to(ROOT.resolve()):
        raise ValueError(f"Path escaped project root: {name}")
    return name


def read_sidecar(checksum: Path) -> str:
    expected = checksum.read_text(encoding="ascii").split()[0].lower()
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid ZIP SHA-256 sidecar")
    return expected


def move_to_done(archive: Path, checksum: Path) -> None:
    DONE.mkdir(parents=True, exist_ok=True)
    archive_target = DONE / archive.name
    checksum_target = DONE / checksum.name

    if archive_target.exists() and sha256_file(archive_target) == sha256_file(archive):
        archive.unlink()
    else:
        os.replace(archive, archive_target)

    if checksum_target.exists() and checksum_target.read_bytes() == checksum.read_bytes():
        checksum.unlink()
    else:
        os.replace(checksum, checksum_target)


def install(archive: Path) -> None:
    checksum = archive.with_suffix(archive.suffix + ".sha256")
    if not checksum.is_file():
        return  # producer/browser may still be copying the sidecar

    expected = read_sidecar(checksum)
    actual = sha256_file(archive)
    if actual != expected:
        raise ValueError("ZIP SHA-256 mismatch")

    current_hash = installed_hash()

    # Crash-recovery/duplicate housekeeping: if state already records exactly
    # this archive, do not apply it again; simply move the leftover files away.
    if expected == current_hash:
        move_to_done(archive, checksum)
        print(f"Already installed {archive.name}; moved duplicate to updates/installed", flush=True)
        return

    with zipfile.ZipFile(archive) as z:
        members = [item for item in z.infolist() if not item.is_dir()]
        names = [item.filename for item in members]

        if len(names) != len(set(names)):
            raise ValueError("Duplicate ZIP members")
        if "manifest.json" not in names:
            raise ValueError("Missing manifest.json")
        if len(names) - 1 > MAX_FILES:
            raise ValueError(f"Too many payload files (max {MAX_FILES})")

        manifest = json.loads(z.read("manifest.json"))
        parent = manifest.get("parent_sha256")
        if not isinstance(parent, str) or not re.fullmatch(r"[0-9a-f]{64}", parent):
            raise ValueError("Missing/invalid parent_sha256")
        if parent != current_hash:
            raise ValueError(
                "Update rejected: expected parent "
                f"{current_hash}, package parent is {parent} "
                "(old, repeated or out-of-order update)"
            )

        updates = manifest.get("files")
        deletes = manifest.get("delete", [])
        if not isinstance(updates, dict):
            raise ValueError("Manifest files must be an object")
        if not isinstance(deletes, list) or not all(isinstance(x, str) for x in deletes):
            raise ValueError("Manifest delete must be a string array")
        if not updates and not deletes:
            raise ValueError("Manifest contains no changes")
        if set(updates).intersection(deletes):
            raise ValueError("A path cannot be both updated and deleted")
        if set(names) != set(updates) | {"manifest.json"}:
            raise ValueError("ZIP entries do not match manifest files")

        payload: dict[str, bytes] = {}
        total_bytes = 0

        for name, hash_value in updates.items():
            validate_project_path(name)
            if not isinstance(hash_value, str) or not re.fullmatch(r"[0-9a-f]{64}", hash_value):
                raise ValueError(f"Invalid file hash in manifest: {name}")

            info = z.getinfo(name)
            if info.file_size > MAX_FILE_BYTES:
                raise ValueError(f"File too large: {name}")
            total_bytes += info.file_size
            if total_bytes > MAX_TOTAL_BYTES:
                raise ValueError("Update payload exceeds total size limit")

            mode = (info.external_attr >> 16) & 0o170000
            if mode not in (0, 0o100000):
                raise ValueError(f"Symlink/special file forbidden: {name}")

            data = z.read(name)
            if sha256_bytes(data) != hash_value:
                raise ValueError(f"File hash mismatch: {name}")
            payload[name] = data

        for name in deletes:
            validate_project_path(name)

    # Everything is validated before the project is touched.
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    history_root = HISTORY / stamp
    touched = list(payload) + list(deletes)
    existed_before: dict[str, bool] = {}

    try:
        for name in touched:
            target = ROOT / Path(*PurePosixPath(name).parts)
            existed_before[name] = target.is_file()
            if target.exists() and not target.is_file():
                raise ValueError(f"Update target is not a regular file: {name}")
            if target.is_file():
                backup = history_root / Path(*PurePosixPath(name).parts)
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)

        for name, data in payload.items():
            target = ROOT / Path(*PurePosixPath(name).parts)
            write_atomic(target, data)

        for name in deletes:
            target = ROOT / Path(*PurePosixPath(name).parts)
            if target.exists():
                target.unlink()

        state = {
            "sha256": expected,
            "package": archive.name,
            "installed_utc": datetime.now(timezone.utc).isoformat(),
            "parent_sha256": current_hash,
        }
        write_atomic(
            RELEASE_FILE,
            (json.dumps(state, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        move_to_done(archive, checksum)

    except Exception:
        # Best-effort rollback of project files.  Keep the history directory for
        # inspection.  Release state is only written after payload application.
        for name in reversed(touched):
            target = ROOT / Path(*PurePosixPath(name).parts)
            backup = history_root / Path(*PurePosixPath(name).parts)
            try:
                if existed_before.get(name) and backup.is_file():
                    write_atomic(target, backup.read_bytes())
                elif not existed_before.get(name) and target.exists() and target.is_file():
                    target.unlink()
            except Exception:
                pass
        raise

    print(
        f"Installed {archive.name}: {len(payload)} updated, "
        f"{len(deletes)} deleted; originals in {history_root}",
        flush=True,
    )


def reject(archive: Path, exc: Exception) -> None:
    checksum = archive.with_suffix(archive.suffix + ".sha256")
    print(f"REJECTED {archive.name}: {exc}", flush=True)
    REJECTED.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for file in (archive, checksum):
        if file.exists():
            destination = REJECTED / file.name
            if destination.exists():
                destination = REJECTED / f"{stamp}-{file.name}"
            os.replace(file, destination)


def scan() -> None:
    INBOX.mkdir(parents=True, exist_ok=True)
    for archive in sorted(INBOX.glob("*.zip")):
        if not archive.with_suffix(archive.suffix + ".sha256").is_file():
            continue
        try:
            install(archive)
        except Exception as exc:
            reject(archive, exc)


def print_status() -> None:
    print(f"SunOpt root: {ROOT}")
    print(f"Inbox:      {INBOX}")
    print(f"Installed:  {installed_hash()}")
    if RELEASE_FILE.exists():
        print(RELEASE_FILE.read_text(encoding="utf-8").rstrip())
    else:
        print("State:      fresh/genesis")


def main() -> None:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--once", action="store_true")
    mode.add_argument("--watch", action="store_true")
    mode.add_argument("--status", action="store_true")
    args = parser.parse_args()

    if args.status:
        print_status()
        return

    scan()
    if args.watch:
        print(f"Watching {INBOX} (Ctrl+C to stop)", flush=True)
        try:
            while True:
                time.sleep(1)
                scan()
        except KeyboardInterrupt:
            print("Watcher stopped", flush=True)


if __name__ == "__main__":
    main()
